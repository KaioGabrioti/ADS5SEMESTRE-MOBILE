package com.example.usjtads3anmcaapphelpdesk;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class ListaChamadaActivity extends AppCompatActivity {

    private ListView chamadosListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_chamados);
        chamadosListView = findViewById(R.id.chamadosListView);

        Intent origemIntent = getIntent();
        String nomeFila = origemIntent.getStringExtra("nome_fila");
        List<String> chamados = busca(nomeFila);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, chamados);
        chamadosListView.setAdapter(adapter);
        chamadosListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClickAdapter(AdapterView<?> parent, View view, int position, long id){
                String chamadosSelecionado = chamados.get(position);
                Toast.makeText(ListaChamadaActivity,this,chamadosSelecionado, Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(ListaChamadaActivity.this, DetalhesChamadoActivity.class);
                intent.putExtra("chamado_selecionado", chamadosSelecionado);
                startActivity(intent);
            }
        });
    }

    public List<String> busca (String nomeFila){
        List<String> chamados = geraListaChamados();
        if(nomeFila == null || nomeFila.length() == 0)
            return chamados
        List<String> resultado = new ArrayList<>();
        for(String chamado : chamados){
            if(chamado.toLowerCase().contains(nomeFila.toLowerCase())){
                resultado.add(chamado);
            }
        }
        return resultado
    }

    public ArrayList<String> geraListaChamados(){
        ArrayList<String> lista = new ArrayList<>();
        lista.add("Desktops: Computador da secretária quebrado.");
        lista.add("Telefonia: Telefone não funciona.");
        lista.add("Redes: Manutenção no proxy.");
        lista.add("Servidores: Lentidão generalizada.");
        lista.add("Novos Projetos: CRM");
        lista.add("Manutenção Sistema ERP: atualizar versão.");
        lista.add("Novos Projetos: Rede MPLS");
        lista.add("Manutenção Sistema de Vendas: incluir pipeline.");
        lista.add("Manutenção Sistema ERP: erro contábil");
        lista.add("Novos Projetos: Gestão de Orçamento");
        lista.add("Novos Projetos: Big Data");
        lista.add("Manoel de Barros");
        lista.add("Redes: Internet com lentidão");
        lista.add("Novos Projetos: Chatbot");
        lista.add("Desktops: troca de senha");
        lista.add("Desktops: falha no Windows");
        lista.add("Novos Projetos: ITIL V3");
        lista.add("Telefonia: liberar celular");
        lista.add("Telefonia: mover ramal");
        lista.add("Redes: ponto com defeito");
        lista.add("Novos Projetos: ferramenta EMM");
        return lista;
    }
}
