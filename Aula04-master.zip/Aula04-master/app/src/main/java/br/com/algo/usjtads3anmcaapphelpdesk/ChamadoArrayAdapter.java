package br.com.algo.usjtads3anmcaapphelpdesk;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Date;
import java.util.List;

public class ChamadoArrayAdapter extends ArrayAdapter<Chamado> {
    public ChamadoArrayAdapter(Context context, List<Chamado> chamados){
        super(context, -1, chamados);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.item_de_lista, parent, false);
        }
        Chamado chamadoDaVez = getItem(position);
        ImageView filaIconImageView = convertView.findViewById(R.id.filaIconImageView);
        TextView descricaoChamadoTextView = convertView.findViewById(R.id.descricaoChamadoNaListaTextView);
        TextView dataAberturaTextView = convertView.findViewById(R.id.dataAberturaTextView);
        TextView dataFechamentoTextView = convertView.findViewById(R.id.dataFechamentoTextView);
        TextView statusDoChamadoTextView =  convertView.findViewById(R.id.statusChamadoTextView);
        filaIconImageView.setImageResource(chamadoDaVez.
                getFila().
                getIconId());
        descricaoChamadoTextView.setText(chamadoDaVez.getDescricao());
        dataAberturaTextView.setText(DateHelper.format(chamadoDaVez.getDataAbertura()));
        if(chamadoDaVez.getDataFechamento() != null){
            dataFechamentoTextView.setText(DateHelper.format(chamadoDaVez.getDataFechamento()));
        }
        statusDoChamadoTextView.setText(chamadoDaVez.getStatus());
        return convertView;
    }
}
